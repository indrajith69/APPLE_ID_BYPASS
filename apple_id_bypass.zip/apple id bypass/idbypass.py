from subprocess import run as execute
from os import chdir as change_directory

change_directory('assets/')
execute('ideviceactivation activate -s servderdfcfv.gearhostpreview.com/sliver.php -d')